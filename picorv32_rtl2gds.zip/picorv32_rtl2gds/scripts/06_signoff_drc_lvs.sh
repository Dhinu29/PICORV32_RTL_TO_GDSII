#!/bin/bash
###############################################################################
# 06_signoff_drc_lvs.sh - Physical signoff wrapper (Cadence Pegasus)
# -----------------------------------------------------------------------------
# TEMPLATE: the exact Pegasus command line and rule-deck variables are given by
# your foundry runset. Replace the DUMMY decks (design_config.tcl) and adjust
# PEGASUS_DRC_CMD / PEGASUS_LVS_CMD to the foundry-supplied runset syntax.
# Gate : DRC = 0 violations, LVS = clean (CORRECT), antenna = 0.
###############################################################################
set -u
: "${PROJ_ROOT:?export PROJ_ROOT}"; : "${RUN_TAG:=run1}"
OUT=$PROJ_ROOT/runs/$RUN_TAG/pnr/outputs
SGN=$PROJ_ROOT/runs/$RUN_TAG/signoff/pegasus
mkdir -p "$SGN"

DRC_DECK=/pdk/foundry45nm/drc/drc_45nm.rul      # DUMMY
LVS_DECK=/pdk/foundry45nm/lvs/lvs_45nm.rul      # DUMMY
TOP=picorv32

# Foundry runset syntax differs: edit these two lines to match yours.
PEGASUS_DRC_CMD="pegasus -drc -gds $OUT/$TOP.gds -top_cell $TOP -rf $DRC_DECK -log_dir $SGN/drc"
PEGASUS_LVS_CMD="pegasus -lvs -gds $OUT/$TOP.gds -top_cell $TOP -source_verilog $OUT/${TOP}_final_pg.v -rf $LVS_DECK -log_dir $SGN/lvs"

echo ">>> DRC";  eval "$PEGASUS_DRC_CMD" 2>&1 | tee "$SGN/drc.log"
echo ">>> LVS";  eval "$PEGASUS_LVS_CMD" 2>&1 | tee "$SGN/lvs.log"
echo "Review $SGN/drc and $SGN/lvs result summaries before tape-out."
