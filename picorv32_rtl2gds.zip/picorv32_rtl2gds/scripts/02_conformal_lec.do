// ############################################################################
// 02_conformal_lec.do  -  Logic equivalence checking (Cadence Conformal LEC)
// ----------------------------------------------------------------------------
// Run: lec -nogui -xl -dofile scripts/02_conformal_lec.do
// Env: PROJ_ROOT, RUN_TAG must be exported (run_flow.sh does it)
// Checks (1) RTL vs Genus netlist  (with scan enable forced to 0)
//        (2) Genus netlist vs final Innovus netlist (run with LEC_STAGE=pnr)
// NOTE : command spelling follows the Conformal 20.x/21.x syntax. If your
//        release warns about an option, check `help <command>`.
// ############################################################################

set log file $env(PROJ_ROOT)/runs/$env(RUN_TAG)/lec/lec.log -replace
set naming rule "%s[%d]" -instance -variable
set undefined cell black_box -noascend -both

// ---- libraries (DUMMY path, same as design_config.tcl) ----
read library -liberty -both -replace \
    /pdk/foundry45nm/stdcell_hvt_rvt/lib/std45_tt_1p00v_25c.lib

// ---- golden = RTL ----
read design -verilog -golden -root picorv32 -replace \
    $env(PROJ_ROOT)/rtl/picorv32.v

// ---- revised = netlist (synth or pnr) ----
// LEC_STAGE=synth -> Genus netlist ; LEC_STAGE=pnr -> Innovus final netlist
if {$env(LEC_STAGE) == "pnr"} {
    read design -verilog -revised -root picorv32 -replace \
        $env(PROJ_ROOT)/runs/$env(RUN_TAG)/pnr/outputs/picorv32_final.v
} else {
    read design -verilog -revised -root picorv32 -replace \
        $env(PROJ_ROOT)/runs/$env(RUN_TAG)/synth/outputs/picorv32_synth.v
}

// ---- DFT: scan enable must be 0 for functional equivalence ----
add pin constraints 0 SE -revised

// ---- compare ----
set system mode lec
add compared points -all
compare

// ---- reports ----
report verification
report compare data -class nonequivalent
report unmapped points
// Expected: scan ports (SE, DFT_sdi_*, DFT_sdo_*) appear only in the revised
// design as "extra"; there must be ZERO non-equivalent and ZERO unmapped
// golden points.
exit -force
