###############################################################################
# mmmc.tcl  -  Multi-Mode Multi-Corner definition (shared by all Cadence tools)
# -----------------------------------------------------------------------------
# Modes   : func  (mission mode)           scan (shift mode, DFT)
# Corners : ss/125C/0.95V + RC-worst  -> SETUP signoff
#           ff/-40C/1.05V + RC-best   -> HOLD  signoff
#           tt/ 25C/1.00V + RC-typ    -> POWER (leakage + dynamic)
#
# Views   : func_ss  func_ff  func_tt  scan_ss  scan_ff
#
# Needs   : $::STAGE = synth | pnr | signoff      (set by calling script)
#           $::TOOL  = genus | innovus | tempus | voltus
# Note    : at stage "synth" the scan SDC cannot be read, because DFT ports
#           (SE, DFT_sdi_*, DFT_sdo_*) do not exist before DFT insertion. So only
#           the func views are built in that stage.
###############################################################################

if {![info exists ::STAGE]} { set ::STAGE pnr }
if {![info exists ::TOOL]}  { set ::TOOL  innovus }

# ---------------------------------------------------------------------------
# 1. Library sets  (one per PVT)
# ---------------------------------------------------------------------------
create_library_set -name lib_ss -timing $::SS_LIBS
create_library_set -name lib_ff -timing $::FF_LIBS
create_library_set -name lib_tt -timing $::TT_LIBS

# ---------------------------------------------------------------------------
# 2. RC corners  (QRC tech file per corner; temperature must match library)
# ---------------------------------------------------------------------------
create_rc_corner -name rc_worst -T 125 -qrc_tech $::QRC_RCWORST
create_rc_corner -name rc_best  -T -40 -qrc_tech $::QRC_RCBEST
create_rc_corner -name rc_typ   -T  25 -qrc_tech $::QRC_RCTYP

# ---------------------------------------------------------------------------
# 3. Delay corners = library set + RC corner
# ---------------------------------------------------------------------------
create_delay_corner -name dc_ss -library_set lib_ss -rc_corner rc_worst
create_delay_corner -name dc_ff -library_set lib_ff -rc_corner rc_best
create_delay_corner -name dc_tt -library_set lib_tt -rc_corner rc_typ

# ---------------------------------------------------------------------------
# 4. Constraint modes
# ---------------------------------------------------------------------------
create_constraint_mode -name mode_func -sdc_files [list $::SDC_FUNC]
if {$::STAGE ne "synth"} {
    create_constraint_mode -name mode_scan -sdc_files [list $::SDC_SCAN]
}

# ---------------------------------------------------------------------------
# 5. Analysis views = constraint mode + delay corner
# ---------------------------------------------------------------------------
create_analysis_view -name func_ss -constraint_mode mode_func -delay_corner dc_ss
create_analysis_view -name func_ff -constraint_mode mode_func -delay_corner dc_ff
create_analysis_view -name func_tt -constraint_mode mode_func -delay_corner dc_tt
if {$::STAGE ne "synth"} {
    create_analysis_view -name scan_ss -constraint_mode mode_scan -delay_corner dc_ss
    create_analysis_view -name scan_ff -constraint_mode mode_scan -delay_corner dc_ff
}

# ---------------------------------------------------------------------------
# 6. Activate views (Innovus / Tempus / Voltus only; Genus uses all views
#    created above)
# ---------------------------------------------------------------------------
if {$::TOOL ne "genus"} {
    set_analysis_view \
        -setup   [list func_ss scan_ss] \
        -hold    [list func_ff scan_ff] \
        -leakage func_tt \
        -dynamic func_tt
}
