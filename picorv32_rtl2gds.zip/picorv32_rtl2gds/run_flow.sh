#!/bin/bash
###############################################################################
# run_flow.sh - one-command driver for the PicoRV32 RTL-to-GDSII flow
# -----------------------------------------------------------------------------
# Usage : ./run_flow.sh <stage|all> [RUN_TAG]
#   stages: synth | lec_synth | pnr | lec_pnr | tempus | voltus | pegasus | all
# Examples:
#   ./run_flow.sh all run1
#   START_STEP=5 STOP_STEP=11 ./run_flow.sh pnr run1     # restart Innovus at CTS
# Needs : genus, innovus, lec, tempus, voltus, pegasus in PATH (module load ...)
###############################################################################
set -u
export PROJ_ROOT=$(cd "$(dirname "$0")" && pwd)
export RUN_TAG=${2:-run1}
export NUM_CPUS=${NUM_CPUS:-8}
RUN=$PROJ_ROOT/runs/$RUN_TAG
mkdir -p "$RUN/logs" "$RUN/lec"
cd "$RUN" || exit 1

# stop the flow if a log contains a tool ERROR line
check_log () {
    if grep -E "^\s*(\*\*ERROR|Error|ERROR)" "$1" | grep -v -i "error_count\|0 error" > /dev/null; then
        echo "!!! Errors found in $1 - fix before continuing"; grep -n -E "\*\*ERROR|^ERROR|^Error" "$1" | head -20; exit 1
    fi
}

run_synth () { genus   -no_gui -f   $PROJ_ROOT/scripts/01_genus_synth_dft.tcl -log $RUN/logs/genus;   check_log $RUN/logs/genus.log; }
run_lec   () { LEC_STAGE=$1 lec -nogui -xl -dofile $PROJ_ROOT/scripts/02_conformal_lec.do > $RUN/logs/lec_$1.log 2>&1;
               grep -q "Compare Results.*PASS\|Equivalent" $RUN/logs/lec_$1.log && echo "LEC $1: see log" ; }
run_pnr   () { innovus -batch -no_gui -files $PROJ_ROOT/scripts/03_innovus_pnr.tcl -log $RUN/logs/innovus; check_log $RUN/logs/innovus.log; }
run_tempus() { tempus  -nowin -files $PROJ_ROOT/scripts/04_tempus_signoff.tcl -log $RUN/logs/tempus; }
run_voltus() { voltus  -no_gui -files $PROJ_ROOT/scripts/05_voltus_power_ir.tcl -log $RUN/logs/voltus; }
run_pegasus(){ bash $PROJ_ROOT/scripts/06_signoff_drc_lvs.sh; }

case "${1:-all}" in
  synth)     run_synth ;;
  lec_synth) run_lec synth ;;
  pnr)       run_pnr ;;
  lec_pnr)   run_lec pnr ;;
  tempus)    run_tempus ;;
  voltus)    run_voltus ;;
  pegasus)   run_pegasus ;;
  all)       run_synth; run_lec synth; run_pnr; run_lec pnr; run_tempus; run_voltus; run_pegasus ;;
  *) echo "unknown stage"; exit 1 ;;
esac
echo "Done: $1 ($RUN_TAG)"
