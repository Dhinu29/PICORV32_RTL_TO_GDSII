###############################################################################
# 04_tempus_signoff.tcl  -  Tempus: signoff static timing analysis (MMMC)
# -----------------------------------------------------------------------------
# Run   : tempus -nowin -files scripts/04_tempus_signoff.tcl -log logs/tempus.log
# Reads : final Innovus netlist + 3 SPEF corners + MMMC (+ SDC inside MMMC)
# Gates : setup WNS >= 0, hold WNS >= 0, no max_tran / max_cap / noise violations
# NOTE  : Tempus command options differ slightly between releases - the log
#         must be reviewed (grep -i "error" logs/tempus.log).
###############################################################################
set ::TOOL  tempus
set ::STAGE signoff

if {[info exists ::env(PROJ_ROOT)]} {
    source $::env(PROJ_ROOT)/config/design_config.tcl
} else {
    source [file join [file dirname [info script]] .. config design_config.tcl]
}
file mkdir $::SIGNOFF_DIR/tempus
set o $::PNR_OUT_DIR
set r $::SIGNOFF_DIR/tempus

set_multi_cpu_usage -local_cpu $::NUM_CPUS

# ---- design ----------------------------------------------------------------
read_mmmc     $::MMMC_FILE
read_physical -lef $::LEF_FILES
read_netlist  $o/${::DESIGN}_final.v -top $::DESIGN
init_design

# ---- parasitics per RC corner ---------------------------------------------
read_spef -rc_corner rc_worst $o/${::DESIGN}_rcworst.spef.gz
read_spef -rc_corner rc_best  $o/${::DESIGN}_rcbest.spef.gz
read_spef -rc_corner rc_typ   $o/${::DESIGN}_rctyp.spef.gz

# ---- analysis settings ------------------------------------------------------
set_db timing_analysis_type  ocv
set_db timing_analysis_cppr  both
set_db delaycal_enable_si    true
set_db si_analysis_type      aae               ;# SI-aware signoff timing

update_timing -full

# ---- reports ------------------------------------------------------------------
report_timing -late  -max_paths 50 -view func_ss  > $r/setup_func_ss.rpt
report_timing -late  -max_paths 50 -view scan_ss  > $r/setup_scan_ss.rpt
report_timing -early -max_paths 50 -view func_ff  > $r/hold_func_ff.rpt
report_timing -early -max_paths 50 -view scan_ff  > $r/hold_scan_ff.rpt
report_constraint -all_violators                   > $r/all_violators.rpt
report_clocks                                      > $r/clocks.rpt
check_timing                                       > $r/check_timing.rpt

puts "Tempus signoff finished. Reports in $r"
exit
