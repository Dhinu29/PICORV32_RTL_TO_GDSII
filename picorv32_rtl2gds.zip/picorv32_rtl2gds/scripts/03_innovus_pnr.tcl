###############################################################################
# 03_innovus_pnr.tcl  -  Innovus: netlist -> GDSII  (45nm, MMMC, DFT-aware)
# -----------------------------------------------------------------------------
# Run     : innovus -batch -no_gui -files scripts/03_innovus_pnr.tcl -log logs/innovus.log
# Restart : START_STEP=5 STOP_STEP=7 innovus ...   (a checkpoint DB is saved after
#           every step in $::PNR_DB_DIR/stepN.enc and reloaded on restart)
#
#  STEP  1  Init design (MMMC, LEF, netlist, SCANDEF)
#  STEP  2  Floorplan + IO pin placement
#  STEP  3  Power planning (global nets, rings, stripes, followpins, taps)
#  STEP  4  Placement + pre-CTS optimisation + pre-CTS timing (setup)
#  STEP  5  Clock tree synthesis (CCOpt) + CTS reports
#  STEP  6  Post-CTS optimisation (setup and hold) + post-CTS timing
#  STEP  7  Routing (NanoRoute, timing + SI driven, antenna)
#  STEP  8  Post-route optimisation (setup + hold) + signoff-grade RC
#  STEP  9  Finishing (fillers, optional metal fill)
#  STEP 10  Verification (DRC, connectivity, antenna, placement, timing, power)
#  STEP 11  Outputs (netlist, SDC, SDF, SPEF, DEF, GDSII, DB)
###############################################################################

set ::TOOL  innovus
set ::STAGE pnr

if {[info exists ::env(PROJ_ROOT)]} {
    source $::env(PROJ_ROOT)/config/design_config.tcl
} else {
    source [file join [file dirname [info script]] .. config design_config.tcl]
}

# --------------------------- helper procs -----------------------------------
proc banner {txt} {
    puts "\n#############################################################"
    puts "# $txt"
    puts "#############################################################"
}
# NON-critical commands: log failure, keep going
proc safe {args} {
    if {[catch {uplevel 1 [join $args " "]} err]} {
        puts "WARNING (non-fatal): [lindex $args 0] failed -> $err"
    }
}
proc step_enabled {n} { return [expr {$n >= $::START_STEP && $n <= $::STOP_STEP}] }
proc save_step {n} {
    write_db $::PNR_DB_DIR/step$n.enc
    puts "Checkpoint saved: step$n.enc"
}

file mkdir $::PNR_OUT_DIR $::PNR_RPT_DIR $::PNR_DB_DIR $::LOG_DIR

# Netlist + SCANDEF coming from Genus
set ::SYN_NETLIST  $::SYN_OUT_DIR/${::DESIGN}_synth.v
set ::SCANDEF      $::SYN_OUT_DIR/${::DESIGN}.scandef

# --------------------------- global tool modes ------------------------------
# Re-applied at every run because not all attributes are stored in the DB.
proc apply_global_modes {} {
    set_db design_process_node            45
    set_db design_bottom_routing_layer    $::BOT_ROUTE_LAYER
    set_db design_top_routing_layer       $::TOP_ROUTE_LAYER
    set_db design_flow_effort             standard

    # timing analysis : on-chip-variation + CPPR + SI
    set_db timing_analysis_type           ocv
    set_db timing_analysis_cppr           both
    set_db delaycal_enable_si             true

    # optimisation targets
    set_db opt_setup_target_slack         $::SETUP_TARGET_SLACK
    set_db opt_hold_target_slack          $::HOLD_TARGET_SLACK

    # placement : IO pins placed by placer, scan chains reordered
    set_db place_global_place_io_pins     true
    set_db place_global_reorder_scan      true

    # routing
    set_db route_design_with_timing_driven true
    set_db route_design_with_si_driven     true
    if {$::ANTENNA_CELL ne ""} {
        set_db route_design_antenna_diode_insertion true
        set_db route_design_antenna_cell_name       $::ANTENNA_CELL
    }
    set_multi_cpu_usage -local_cpu $::NUM_CPUS
}

# ============================================================================
# STEP 1 : INIT DESIGN
# ============================================================================
if {$::START_STEP == 1} {
    banner "STEP 1: init design"
    set_db init_power_nets   $::PWR_NET
    set_db init_ground_nets  $::GND_NET

    read_mmmc     $::MMMC_FILE                ;# 2 modes x 3 corners (see mmmc.tcl)
    read_physical -lef $::LEF_FILES
    read_netlist  $::SYN_NETLIST -top $::DESIGN
    init_design
    apply_global_modes

    # sanity : netlist/LEF/lib consistency
    check_design -type {all} -out_file $::PNR_RPT_DIR/check_design_init.rpt
    save_step 1
} else {
    # restart : reload checkpoint of previous step
    banner "RESTART from step[expr {$::START_STEP-1}]"
    read_db $::PNR_DB_DIR/step[expr {$::START_STEP-1}].enc
    apply_global_modes
}

# ============================================================================
# STEP 2 : FLOORPLAN + SCANDEF + PINS
# ============================================================================
if {[step_enabled 2]} {
    banner "STEP 2: floorplan"
    # aspect ratio, utilisation, margins (left bottom right top) in um
    create_floorplan -site $::CORE_SITE \
        -core_density_size $::FP_ASPECT $::FP_UTIL \
        $::FP_MARGIN $::FP_MARGIN $::FP_MARGIN $::FP_MARGIN

    # DFT : read scan chains so the placer keeps them short / reorders flops
    if {$::DFT_ENABLE && [file exists $::SCANDEF]} {
        read_def $::SCANDEF
    }
    # (no hard macros in PicoRV32 - the 32x32 regfile is flop based)
    report_summary -no_html -out_dir $::PNR_RPT_DIR/floorplan
    save_step 2
}

# ============================================================================
# STEP 3 : POWER PLANNING
#   - connect PG pins globally
#   - well taps / endcaps
#   - core rings (metal9/10), mesh stripes, standard-cell rails (followpins)
# ============================================================================
if {[step_enabled 3]} {
    banner "STEP 3: power planning"

    # 3.1 global net connection (all instances, tie cells too)
    connect_global_net $::PWR_NET -type pg_pin -pin_base_name VDD -all -verbose
    connect_global_net $::GND_NET -type pg_pin -pin_base_name VSS -all -verbose
    connect_global_net $::PWR_NET -type tie_hi -all
    connect_global_net $::GND_NET -type tie_lo -all

    # 3.2 well taps (latch-up protection) and endcaps
    if {$::TAP_CELL ne ""} {
        add_well_taps -cell $::TAP_CELL -cell_interval 30 -in_row_offset 5 -prefix WELLTAP
    }
    if {$::ENDCAP_CELL ne ""} {
        set_db add_endcaps_left_edge  $::ENDCAP_CELL
        set_db add_endcaps_right_edge $::ENDCAP_CELL
        add_endcaps -prefix ENDCAP
    }

    # 3.3 core power rings
    add_rings -nets [list $::PWR_NET $::GND_NET] -type core_rings -follow core \
        -layer [list top $::PG_RING_H bottom $::PG_RING_H left $::PG_RING_V right $::PG_RING_V] \
        -width 2.0 -spacing 1.0 -offset 1.0

    # 3.4 power mesh: vertical stripes + horizontal stripes
    add_stripes -nets [list $::PWR_NET $::GND_NET] -layer $::PG_STRIPE_V -direction vertical \
        -width 1.0 -spacing 1.0 -set_to_set_distance 20.0 \
        -start_from left -start_offset 5.0
    add_stripes -nets [list $::PWR_NET $::GND_NET] -layer $::PG_STRIPE_H -direction horizontal \
        -width 1.0 -spacing 1.0 -set_to_set_distance 20.0 \
        -start_from bottom -start_offset 5.0

    # 3.5 standard-cell rails (followpins on metal1) + via stack to the mesh
    route_special -connect core_pin -nets [list $::PWR_NET $::GND_NET] \
        -allow_layer_change 1 -allow_jogging 1 \
        -crossover_via_layer_range [list $::PG_BOT_LAYER $::PG_TOP_LAYER] \
        -target_via_layer_range    [list $::PG_BOT_LAYER $::PG_TOP_LAYER]

    # 3.6 early PG sanity
    safe check_drc -limit 500 -out_file $::PNR_RPT_DIR/drc_after_powerplan.rpt
    safe check_connectivity -type special -nets [list $::PWR_NET $::GND_NET] \
        -out_file $::PNR_RPT_DIR/pg_connectivity.rpt
    save_step 3
}

# ============================================================================
# STEP 4 : PLACEMENT + PRE-CTS OPTIMISATION
# ============================================================================
if {[step_enabled 4]} {
    banner "STEP 4: placement + pre-CTS opt"
    check_design -type {place} -out_file $::PNR_RPT_DIR/check_design_place.rpt

    place_opt_design -out_dir $::PNR_RPT_DIR/place          ;# global place + opt + legalise
    safe check_place -out_file $::PNR_RPT_DIR/check_place.rpt
    safe report_congestion -hotspot > $::PNR_RPT_DIR/congestion_post_place.rpt

    # pre-CTS : clocks are IDEAL here
    opt_design -pre_cts
    time_design -pre_cts -report_dir $::PNR_RPT_DIR/timing_pre_cts
    save_step 4
}

# ============================================================================
# STEP 5 : CLOCK TREE SYNTHESIS (CCOpt)
# ============================================================================
if {[step_enabled 5]} {
    banner "STEP 5: CTS"
    check_design -type {cts} -out_file $::PNR_RPT_DIR/check_design_cts.rpt

    set_db cts_buffer_cells    $::CTS_BUF_CELLS
    set_db cts_inverter_cells  $::CTS_INV_CELLS
    if {[llength $::CTS_ICG_CELLS] > 0} {
        set_db cts_clock_gating_cells $::CTS_ICG_CELLS
    }
    set_db cts_target_skew                    0.080     ;# ns
    set_db cts_target_max_transition_time_top   0.200
    set_db cts_target_max_transition_time_trunk 0.200
    set_db cts_target_max_transition_time_leaf  0.200

    create_ccopt_clock_tree_spec -immediate -keep_all_sdc_clocks
    ccopt_design                                           ;# build tree + optimise

    safe report_ccopt_clock_trees -file $::PNR_RPT_DIR/cts_clock_trees.rpt
    safe report_ccopt_skew_groups -file $::PNR_RPT_DIR/cts_skew_groups.rpt
    time_design -post_cts -report_dir $::PNR_RPT_DIR/timing_post_cts_setup
    save_step 5
}

# ============================================================================
# STEP 6 : POST-CTS OPTIMISATION (setup + hold)  - clocks now PROPAGATED
# ============================================================================
if {[step_enabled 6]} {
    banner "STEP 6: post-CTS opt"
    opt_design -post_cts                       ;# setup
    opt_design -post_cts -hold                 ;# hold fixing (delay cells / buffers)
    time_design -post_cts        -report_dir $::PNR_RPT_DIR/timing_post_cts_final_setup
    time_design -post_cts -hold  -report_dir $::PNR_RPT_DIR/timing_post_cts_final_hold
    save_step 6
}

# ============================================================================
# STEP 7 : ROUTING (NanoRoute)
# ============================================================================
if {[step_enabled 7]} {
    banner "STEP 7: route"
    check_design -type {route} -out_file $::PNR_RPT_DIR/check_design_route.rpt
    route_design                               ;# global + detail route (timing/SI driven)
    time_design -post_route -report_dir $::PNR_RPT_DIR/timing_post_route_pre_opt
    save_step 7
}

# ============================================================================
# STEP 8 : POST-ROUTE OPTIMISATION
# ============================================================================
if {[step_enabled 8]} {
    banner "STEP 8: post-route opt"
    set_db extract_rc_engine       post_route
    set_db extract_rc_effort_level high
    opt_design -post_route -setup -hold
    time_design -post_route        -report_dir $::PNR_RPT_DIR/timing_post_route_setup
    time_design -post_route -hold  -report_dir $::PNR_RPT_DIR/timing_post_route_hold
    save_step 8
}

# ============================================================================
# STEP 9 : FINISHING - fillers (and optional metal fill)
# ============================================================================
if {[step_enabled 9]} {
    banner "STEP 9: finishing"
    if {[llength $::DECAP_CELLS] > 0} {
        safe add_fillers -base_cell $::DECAP_CELLS -prefix DECAP
    }
    add_fillers -base_cell $::FILLER_CELLS -prefix FILLER
    if {$::DO_METAL_FILL} {
        # layer list and rules are foundry-specific: tune before enabling
        safe add_metal_fill -layer [list metal1 metal2 metal3 metal4 metal5 metal6] \
            -nets [list $::PWR_NET $::GND_NET]
    }
    save_step 9
}

# ============================================================================
# STEP 10 : VERIFICATION
# ============================================================================
if {[step_enabled 10]} {
    banner "STEP 10: verification"
    check_drc               -limit 1000 -out_file $::PNR_RPT_DIR/final_drc.rpt
    check_connectivity      -type all   -out_file $::PNR_RPT_DIR/final_connectivity.rpt
    check_process_antenna               -out_file $::PNR_RPT_DIR/final_antenna.rpt
    check_place                         -out_file $::PNR_RPT_DIR/final_place.rpt

    # signoff-quality extraction (Quantus QRC engine inside Innovus)
    set_db extract_rc_engine       post_route
    set_db extract_rc_effort_level signoff
    extract_rc
    time_design -post_route        -report_dir $::PNR_RPT_DIR/timing_final_setup
    time_design -post_route -hold  -report_dir $::PNR_RPT_DIR/timing_final_hold

    report_power -out_file $::PNR_RPT_DIR/power_final.rpt
    report_area  -out_file $::PNR_RPT_DIR/area_final.rpt
    safe report_summary -no_html -out_dir $::PNR_RPT_DIR/summary_final
    save_step 10
}

# ============================================================================
# STEP 11 : OUTPUTS (hand-off to LVS, signoff STA, power, tape-out)
# ============================================================================
if {[step_enabled 11]} {
    banner "STEP 11: write outputs"
    set o $::PNR_OUT_DIR

    # netlists: logical (LEC/STA) and with PG (LVS / gate-level power sim)
    write_netlist $o/${::DESIGN}_final.v
    write_netlist -include_pg_ports -omit_floating_ports $o/${::DESIGN}_final_pg.v

    # constraints, delays, parasitics
    safe write_sdc  -view $::SETUP_VIEW $o/${::DESIGN}_final_setup.sdc
    safe write_sdc  -view $::HOLD_VIEW  $o/${::DESIGN}_final_hold.sdc
    safe write_sdf  -view $::SETUP_VIEW $o/${::DESIGN}_final_setup.sdf
    safe write_sdf  -view $::HOLD_VIEW  $o/${::DESIGN}_final_hold.sdf
    safe write_parasitics -rc_corner rc_worst -spef_file $o/${::DESIGN}_rcworst.spef.gz
    safe write_parasitics -rc_corner rc_best  -spef_file $o/${::DESIGN}_rcbest.spef.gz
    safe write_parasitics -rc_corner rc_typ   -spef_file $o/${::DESIGN}_rctyp.spef.gz

    # physical
    write_def -scan -routing $o/${::DESIGN}_final.def.gz
    write_db $o/${::DESIGN}_final.enc

    # GDSII : merge std-cell GDS, map layers
    write_stream $o/${::DESIGN}.gds \
        -map_file   $::GDS_MAP \
        -lib_name   $::GDS_LIBNAME \
        -merge      [list $::STD_GDS] \
        -unit       $::GDS_UNITS \
        -mode       ALL
    puts "\nGDSII written: $o/${::DESIGN}.gds"
}

banner "Innovus flow complete"
exit
