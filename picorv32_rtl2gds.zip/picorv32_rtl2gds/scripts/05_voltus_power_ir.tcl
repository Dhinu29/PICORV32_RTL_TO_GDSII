###############################################################################
# 05_voltus_power_ir.tcl  -  Voltus: power analysis + static IR drop / EM
# -----------------------------------------------------------------------------
# Run   : voltus -no_gui -files scripts/05_voltus_power_ir.tcl -log logs/voltus.log
# Needs : final DEF/netlist/SPEF, QRC tech file.  Uses a "tech-only" PG library
#         (no per-cell PG views) which is fine for a flat std-cell block;
#         for tape-out generate full cell PG libraries with your release.
# Gate  : worst static IR drop < ::IR_DROP_LIMIT_PCT % of VDD
# NOTE  : rail-analysis options change between Voltus releases - verify the
#         first run against the Voltus User Guide of your version.
###############################################################################
set ::TOOL  voltus
set ::STAGE signoff

if {[info exists ::env(PROJ_ROOT)]} {
    source $::env(PROJ_ROOT)/config/design_config.tcl
} else {
    source [file join [file dirname [info script]] .. config design_config.tcl]
}
set o $::PNR_OUT_DIR
set r $::SIGNOFF_DIR/voltus
file mkdir $r

set_multi_cpu_usage -local_cpu $::NUM_CPUS

# ---- load design -----------------------------------------------------------
set_db init_power_nets  $::PWR_NET
set_db init_ground_nets $::GND_NET
read_mmmc     $::MMMC_FILE
read_physical -lef $::LEF_FILES
read_netlist  $o/${::DESIGN}_final_pg.v -top $::DESIGN
init_design
read_def      $o/${::DESIGN}_final.def.gz
read_spef -rc_corner rc_typ $o/${::DESIGN}_rctyp.spef.gz

# ---- 1. power analysis (switching activity: 20 % default) --------------------
set_power_analysis_mode -method static -analysis_view $::POWER_VIEW \
    -corner typical -create_binary_db true -write_static_currents true \
    -honor_negative_energy true -ignore_control_signals true
set_default_switching_activity -input_activity 0.2 -period $::CLK_PERIOD
set_power_output_dir $r/power
report_power -outfile $r/power_summary.rpt

# ---- 2. static rail analysis (IR drop) ---------------------------------------
set_pg_library_mode -celltype techonly -extraction_tech_file $::QRC_RCTYP \
    -default_area_cap 0.5 -power_pins [list $::PWR_NET $::VDD_NOMINAL] \
    -ground_pins $::GND_NET
generate_pg_library -output $r/pgv

set_rail_analysis_mode -method era_static -accuracy xd \
    -power_switch_eco false -extraction_tech_file $::QRC_RCTYP \
    -temp_directory_name $r/tmp

set vmin [expr {$::VDD_NOMINAL*(100.0-$::IR_DROP_LIMIT_PCT)/100.0}]
set_pg_nets -net $::PWR_NET -voltage $::VDD_NOMINAL -threshold $vmin
set_pg_nets -net $::GND_NET -voltage 0.0 -threshold [expr {$::VDD_NOMINAL*$::IR_DROP_LIMIT_PCT/100.0}]

set_rail_analysis_domain -name core -pwrnets [list $::PWR_NET] -gndnets [list $::GND_NET]
set_power_data -format current -scale 1 $r/power/static_${::POWER_VIEW}.ptiavg

analyze_rail -type domain -results_directory $r/rail core

puts "Voltus finished. Check $r/rail for IR-drop / EM maps."
exit
