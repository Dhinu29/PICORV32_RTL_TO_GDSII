###############################################################################
# picorv32_scan.sdc  -  scan SHIFT mode constraints (used from Innovus onward)
# -----------------------------------------------------------------------------
# Same physical clock port as functional mode, but:
#   * SE = 1 (shift), tied with set_case_analysis
#   * slow shift clock (tester friendly)
#   * only scan ports are timed; functional I/O are false-pathed
# Scan CAPTURE timing (SE = 0) is the functional mode, already covered by
# picorv32_func.sdc, so only shift is constrained here.
###############################################################################

if {![info exists ::SCAN_PERIOD]} { set ::SCAN_PERIOD 20.0 }
set SP $::SCAN_PERIOD

create_clock -name clk -period $SP -waveform [list 0 [expr {$SP/2.0}]] [get_ports clk]
set_clock_uncertainty -setup 0.30 [get_clocks clk]
set_clock_uncertainty -hold  0.05 [get_clocks clk]
set_clock_transition 0.10 [get_clocks clk]

# ---- scan ports (created by Genus connect_scan_chains) ----
set scan_si [get_ports DFT_sdi_*]
set scan_so [get_ports DFT_sdo_*]
set scan_se [get_ports SE]

set_case_analysis 1 $scan_se                       ;# shift mode

set_input_delay  -clock clk -max [expr {0.30*$SP}] [add_to_collection $scan_si $scan_se]
set_input_delay  -clock clk -min 0.50              [add_to_collection $scan_si $scan_se]
set_output_delay -clock clk -max [expr {0.30*$SP}] $scan_so
set_output_delay -clock clk -min 0.00              $scan_so

set_driving_cell -lib_cell BUF_X2 -pin Z [add_to_collection $scan_si $scan_se]
set_load 0.050 $scan_so

# ---- functional I/O are not part of shift timing ----
set func_in  [remove_from_collection [all_inputs] [add_to_collection [add_to_collection $scan_si $scan_se] [get_ports clk]]]
set func_out [remove_from_collection [all_outputs] $scan_so]
set_false_path -from $func_in
set_false_path -to   $func_out

set_max_transition 0.40 [current_design]
