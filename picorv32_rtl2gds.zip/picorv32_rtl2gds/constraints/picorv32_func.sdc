###############################################################################
# picorv32_func.sdc  -  functional (mission-mode) constraints
# -----------------------------------------------------------------------------
# * Works BEFORE and AFTER DFT insertion: DFT ports are guarded with -quiet
# * Units: ns / pF  (match your .lib time_unit / capacitive_load_unit)
# * Tunable numbers come from design_config.tcl ( ::CLK_PERIOD ) with fallbacks
###############################################################################

if {![info exists ::CLK_PERIOD]} { set ::CLK_PERIOD 3.0 }
set P $::CLK_PERIOD

# ---------------------------------------------------------------------------
# Clock
# ---------------------------------------------------------------------------
create_clock -name clk -period $P -waveform [list 0 [expr {$P/2.0}]] [get_ports clk]

set_clock_uncertainty -setup [expr {0.08*$P}] [get_clocks clk]   ;# jitter + skew margin
set_clock_uncertainty -hold  0.05              [get_clocks clk]
set_clock_transition 0.10 [get_clocks clk]                       ;# ideal-clock slew (pre-CTS only)
set_clock_latency    0.00 [get_clocks clk]                       ;# ideal pre-CTS; CTS replaces it

# ---------------------------------------------------------------------------
# Port collections
# ---------------------------------------------------------------------------
set func_in [remove_from_collection [all_inputs] [get_ports clk]]

# DFT ports (exist only after Genus DFT insertion)
set dft_in  [get_ports -quiet [list SE DFT_sdi_*]]
set dft_out [get_ports -quiet DFT_sdo_*]

if {[sizeof_collection $dft_in] > 0} {
    set func_in [remove_from_collection $func_in $dft_in]
}
set func_out [all_outputs]
if {[sizeof_collection $dft_out] > 0} {
    set func_out [remove_from_collection $func_out $dft_out]
}

# ---------------------------------------------------------------------------
# I/O timing  (60 % of the period is consumed outside the block)
# ---------------------------------------------------------------------------
set_input_delay  -clock clk -max [expr {0.60*$P}] $func_in
set_input_delay  -clock clk -min 0.20             $func_in
set_output_delay -clock clk -max [expr {0.60*$P}] $func_out
set_output_delay -clock clk -min 0.00             $func_out

# ---------------------------------------------------------------------------
# Environment (replace lib_cell / pin by real names of your library)
# ---------------------------------------------------------------------------
set_driving_cell -lib_cell BUF_X2 -pin Z $func_in
set_load 0.050 $func_out                 ;# pF

# ---------------------------------------------------------------------------
# Design rules
# ---------------------------------------------------------------------------
set_max_transition 0.40 [current_design]
set_max_fanout     32   [current_design]

# ---------------------------------------------------------------------------
# DFT ports in FUNCTIONAL mode: scan disabled, no timing on scan ports
# ---------------------------------------------------------------------------
if {[sizeof_collection [get_ports -quiet SE]] > 0} {
    set_case_analysis 0 [get_ports SE]
}
if {[sizeof_collection $dft_in] > 0}  { set_false_path -from $dft_in }
if {[sizeof_collection $dft_out] > 0} { set_false_path -to   $dft_out }

# ---------------------------------------------------------------------------
# Timing exceptions
#   PicoRV32 is a single-clock, synchronous-reset design: no multicycle or
#   CDC exceptions are needed.  Add real ones here only after verifying them
#   in RTL.
# ---------------------------------------------------------------------------
