from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak, Table, TableStyle, Preformatted
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.units import cm

ss = getSampleStyleSheet()
NAVY = colors.HexColor('#1F3A5F')
H1 = ParagraphStyle('H1', parent=ss['Heading1'], fontSize=16, spaceBefore=14, textColor=NAVY)
H2 = ParagraphStyle('H2', parent=ss['Heading2'], fontSize=12.5, spaceBefore=10, textColor=NAVY)
B = ParagraphStyle('B', parent=ss['BodyText'], fontSize=10, leading=14, spaceAfter=4)
C = ParagraphStyle('C', parent=ss['Code'], fontSize=8.5, leading=10.5, backColor=colors.HexColor('#F2F4F7'), borderPadding=4)
T = ParagraphStyle('T', parent=ss['Title'], fontSize=22, textColor=NAVY)
cell = ParagraphStyle('cell', parent=B, fontSize=8.8, leading=11, spaceAfter=0)
hcell = ParagraphStyle('hcell', parent=cell, textColor=colors.white, fontName='Helvetica-Bold')

def p(t): return Paragraph(t, B)
def code(t): return Preformatted(t, C)
def tbl(data, widths):
    d = [[Paragraph(str(c), hcell if i == 0 else cell) for c in r] for i, r in enumerate(data)]
    t = Table(d, colWidths=widths, repeatRows=1)
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),NAVY),('GRID',(0,0),(-1,-1),0.4,colors.grey),
        ('VALIGN',(0,0),(-1,-1),'TOP'),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#F2F4F7')])]))
    return t

s = []
s += [Spacer(1,3*cm), Paragraph("PicoRV32 RTL-to-GDSII Flow", T),
      Paragraph("Cadence Genus / Innovus / Tempus / Voltus - 45nm, MMMC, DFT", ss['Heading2']),
      Spacer(1,1*cm),
      p("This guide explains how to run the scripted flow in <b>picorv32_rtl2gds/</b>. Every path to a PDK file is a <b>DUMMY</b> and must be replaced in <b>config/design_config.tcl</b> before the first run."),
      Spacer(1,0.5*cm),
      p("<b>Important honesty note.</b> The scripts were written and syntax-balance-checked, but they could <b>not</b> be executed here because no Cadence tools or 45nm PDK are available. Command names follow the Genus/Innovus 20.x-21.x common UI. Some option names differ between releases, so the first run on your machine will probably need small fixes. Section 9 explains how to find them quickly. Non-critical commands are wrapped in <i>safe</i> so one unsupported option does not kill the flow."),
      PageBreak()]

s += [Paragraph("1. Flow overview", H1),
      tbl([["Stage","Tool","Script","Main output"],
           ["Synthesis + DFT","Genus","01_genus_synth_dft.tcl","netlist, SCANDEF, SDC, reports"],
           ["Equivalence check","Conformal LEC","02_conformal_lec.do","RTL = netlist proof"],
           ["Place and route to GDS","Innovus","03_innovus_pnr.tcl","final netlist, SPEF, DEF, GDSII"],
           ["Signoff timing","Tempus","04_tempus_signoff.tcl","setup/hold violators"],
           ["Power and IR drop","Voltus","05_voltus_power_ir.tcl","power, IR/EM maps"],
           ["DRC / LVS","Pegasus","06_signoff_drc_lvs.sh","DRC/LVS results"]],
          [3.3*cm,2.8*cm,5.2*cm,5.2*cm]),
      Spacer(1,8),
      p("One driver, <b>run_flow.sh</b>, runs everything: <font face='Courier'>./run_flow.sh all run1</font>. Single stages: synth, lec_synth, pnr, lec_pnr, tempus, voltus, pegasus."),
      Paragraph("Directory layout", H2),
      code("""picorv32_rtl2gds/
  run_flow.sh              driver
  config/design_config.tcl ALL paths, numbers, cell names (edit here)
  config/mmmc.tcl          modes x corners x views
  constraints/             picorv32_func.sdc, picorv32_scan.sdc
  scripts/                 01..06
  rtl/                     put picorv32.v here
  runs/<RUN_TAG>/          logs, synth, pnr, signoff, lec (auto-created)"""),
      PageBreak()]

s += [Paragraph("2. Prerequisites and setup", H1),
      p("1. Copy <b>picorv32.v</b> into <b>rtl/</b>. The testbench (axi4_memory, picorv32_wrapper) is simulation only and is <b>not</b> synthesised."),
      p("2. Open <b>config/design_config.tcl</b> and replace every line marked DUMMY: .lib files per corner, tech and cell LEF, QRC tech files, cell GDS, GDS layer map, DRC/LVS decks."),
      p("3. Replace cell names: clock buffers/inverters, fillers, tap, antenna diode, and the BUF_X2 / pin Z used in the SDC driving cell."),
      p("4. Check metal layer names (metal1..metal10 assumed; odd horizontal, even vertical) and the PG pin names VDD / VSS."),
      p("5. Load the tools (module load), then run <font face='Courier'>./run_flow.sh synth run1</font>."),
      Paragraph("PicoRV32 notes that matter", H2),
      p("<b>Top module.</b> Default is <i>picorv32</i> (native memory interface). Use <i>picorv32_axi</i> by changing ::DESIGN."),
      p("<b>Register file.</b> The 32x32 register file is an inferred array and becomes about 1024 flip-flops. It dominates area and is the bulk of the scan chain. Set ENABLE_REGS_16_31 to 0 for a smaller RV32E-style core."),
      p("<b>Parameters.</b> ENABLE_MUL, ENABLE_DIV, ENABLE_IRQ, COMPRESSED_ISA and others default to 0. Edit the defaults in a <b>copy</b> of picorv32.v to enable them, never in place."),
      p("<b>Reset.</b> Reset is synchronous, so DFT sees no asynchronous reset. Clock gating is not inserted: this keeps DFT simple and safe. Adding ICGs requires a test-enable hookup."),
      PageBreak()]

s += [Paragraph("3. MMMC (config/mmmc.tcl)", H1),
      tbl([["Item","Definition"],
           ["Modes","mode_func (mission), mode_scan (shift, SE=1)"],
           ["SS corner","0.95 V, 125 C, RC-worst: setup signoff"],
           ["FF corner","1.05 V, -40 C, RC-best: hold signoff"],
           ["TT corner","1.00 V, 25 C, RC-typical: leakage and dynamic power"],
           ["Views","func_ss, func_ff, func_tt, scan_ss, scan_ff"]],[4*cm,12.5*cm]),
      Spacer(1,6),
      p("The same file is used by Genus, Innovus, Tempus and Voltus. It is <b>stage aware</b>: at stage synth only func views are built, because scan ports (SE, DFT_sdi_*, DFT_sdo_*) do not exist before DFT insertion. From Innovus onward scan views are added. SDC files use guarded commands (<i>get_ports -quiet</i>), so the functional SDC works both before and after DFT."),
      Paragraph("4. Step-by-step: Genus synthesis with DFT", H1),
      tbl([["Step","What happens"],
           ["S1-S2","Setup, read MMMC, LEF, RTL"],
           ["S3","elaborate, init_design, check_design -unresolved, check_timing_intent"],
           ["S4","effort settings, dont_use cells, PLE interconnect"],
           ["S5","muxed-scan style, scan-enable port SE, scan map mode tdrc_pass"],
           ["S6-S7","syn_generic, syn_map (flops mapped to scan flops if they pass DFT rules)"],
           ["S8","check_dft_rules, then connect_scan_chains with 4 balanced chains"],
           ["S9","syn_opt"],
           ["S10-S11","QoR, timing, area, power, scan reports; write netlist, SDC, SCANDEF, ATPG data"]],[2.5*cm,14*cm]),
      Spacer(1,6),
      p("<b>Gate to continue:</b> zero unresolved references, zero DFT rule violations, setup slack >= 0, scan registers covering all flops (see scan_registers_final.rpt)."),
      PageBreak()]

s += [Paragraph("5. DFT in detail", H1),
      p("Style is muxed scan on one rising-edge clock. Genus creates input ports SE and DFT_sdi_0..3 and output ports DFT_sdo_0..3. Shift-mode timing is constrained in picorv32_scan.sdc at 20 ns (50 MHz); capture timing is the functional mode with SE=0."),
      p("The SCANDEF written by Genus is read in Innovus step 2. With place_global_reorder_scan true, the placer reorders scan connections to shorten wires. The final DEF is written with <i>-scan</i>."),
      p("<b>ATPG.</b> The flow writes ATPG hand-off data via write_dft_atpg. Pattern generation itself is done in Modus (build_model, build_testmode, verify_test_structures, build_faultmodel, create_scan_chain_tests, create_logic_tests, write_vectors). A Modus script is not included because it depends on your library models."),
      p("<b>LEC with DFT.</b> The LEC do-file forces SE=0 on the revised side. Scan ports show up as extra points in the netlist; that is expected. Non-equivalent points must be zero."),
      Paragraph("6. Step-by-step: Innovus", H1),
      tbl([["Step","Action","Key commands"],
           ["1","Init design","read_mmmc, read_physical, read_netlist, init_design"],
           ["2","Floorplan","create_floorplan (65% util), read_def SCANDEF, pin placement by placer"],
           ["3","Power planning","connect_global_net, add_well_taps, add_rings (M9/M10), add_stripes (mesh), route_special followpins"],
           ["4","Placement + pre-CTS","place_opt_design, opt_design -pre_cts, time_design -pre_cts"],
           ["5","CTS","cts_* cells/skew/slew, create_ccopt_clock_tree_spec, ccopt_design, clock tree reports"],
           ["6","Post-CTS","opt_design -post_cts, -post_cts -hold, time_design -post_cts (setup+hold)"],
           ["7","Route","route_design (timing + SI driven, antenna diodes)"],
           ["8","Post-route opt","opt_design -post_route -setup -hold, time_design -post_route"],
           ["9","Finish","add_fillers (optional metal fill)"],
           ["10","Verify","check_drc, check_connectivity, check_process_antenna, signoff-effort extraction, timing, power"],
           ["11","Outputs","netlists, SDC, SDF, SPEF x3, DEF, DB, write_stream GDSII"]],[1.2*cm,3.3*cm,12*cm]),
      Spacer(1,6),
      p("A checkpoint DB is saved after each step. To restart: <font face='Courier'>START_STEP=5 STOP_STEP=11 ./run_flow.sh pnr run1</font>."),
      PageBreak()]

s += [Paragraph("7. Power planning details", H1),
      tbl([["Item","Setting (edit in design_config.tcl)"],
           ["Global nets","VDD / VSS connected to all pg pins, tie-hi, tie-lo"],
           ["Well taps","TAP_X1 every 30 um, row offset 5 um (skip if library has none)"],
           ["Core ring","metal9 top/bottom, metal10 left/right, 2.0 um wide, 1.0 um spacing"],
           ["Mesh","metal10 vertical + metal9 horizontal, 1.0 um wide, pitch 20 um"],
           ["Std-cell rails","route_special -connect core_pin with via stack metal1 to metal10"],
           ["IR budget","5% of VDD static, checked in Voltus"]],[4*cm,12.5*cm]),
      Paragraph("8. Signoff criteria (tape-out checklist)", H1),
      tbl([["Check","Tool","Pass criterion"],
           ["Equivalence RTL vs synth","Conformal","0 non-equivalent, 0 unmapped golden"],
           ["Equivalence synth vs final","Conformal","same (LEC_STAGE=pnr)"],
           ["Setup (func and scan, SS)","Tempus","WNS >= 0, TNS = 0"],
           ["Hold (func and scan, FF)","Tempus","WNS >= 0, TNS = 0"],
           ["Max transition / cap / fanout","Tempus","0 violations"],
           ["DRC","Innovus then Pegasus","0 violations in Pegasus"],
           ["LVS","Pegasus","clean"],
           ["Antenna","Innovus/Pegasus","0 violations"],
           ["IR drop","Voltus","< 5% VDD"],
           ["Connectivity","Innovus","0 opens / shorts"]],[5.5*cm,3.8*cm,7.2*cm]),
      PageBreak()]

s += [Paragraph("9. Fixing first-run problems", H1),
      p("1. After each stage run <font face='Courier'>grep -n -i 'error' runs/run1/logs/*.log</font>. Genus and Innovus print the offending command; type <font face='Courier'>help &lt;command&gt;</font> inside the tool to see the options for your release."),
      p("2. Most likely friction: elaboration option names, write_dft_atpg options, create_rc_corner options, write_stream option names, report_* redirect syntax, Voltus rail-analysis options (the static current file name written by the power step must match what set_power_data reads), Pegasus command line (use your foundry runset)."),
      p("3. Timing does not close: relax ::CLK_PERIOD in design_config.tcl first (3.0 ns is a starting guess for a flop-based 32x32 register file), then rerun."),
      p("4. Congestion or DRC after route: lower ::FP_UTIL to 0.55, re-run from step 2."),
      p("5. Hold violations after CTS: raise ::HOLD_TARGET_SLACK to 0.05 and rerun steps 6 to 11."),
      Paragraph("10. What is not included (and why)", H1),
      p("Clock gating insertion, power domains / UPF, hard macros (none in PicoRV32), Modus ATPG scripts, ECO flow, and foundry-specific metal-fill/dummy rules. These need your library and foundry documents. The scripts are structured so each can be added as a new step."),
      p("<b>Before tape-out</b>, always review results with the foundry-provided runsets and your PDK documentation; these scripts are a complete scripted skeleton, not a certified signoff recipe.")]

doc = SimpleDocTemplate("PicoRV32_RTL2GDS_Flow_Guide.pdf", pagesize=A4, leftMargin=2*cm, rightMargin=2*cm,
      topMargin=2*cm, bottomMargin=2*cm, title="PicoRV32 RTL-to-GDSII Flow Guide")
doc.build(s)
