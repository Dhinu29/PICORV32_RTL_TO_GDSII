###############################################################################
# design_config.tcl
# -----------------------------------------------------------------------------
# Project  : PicoRV32 (RV32I) RTL-to-GDSII, 45nm, Cadence digital flow
# Purpose  : SINGLE SOURCE OF TRUTH for every path / number / cell name used by
#            Genus, Innovus, Tempus and Voltus scripts.
#            Edit ONLY this file (and the SDC files) when you move to your real
#            PDK.  All paths below are DUMMY - replace them.
# Usage    : sourced automatically by every script in scripts/
###############################################################################

# ---------------------------------------------------------------------------
# helper: take value from environment variable if set, else default
# ---------------------------------------------------------------------------
proc cfg_env {name default} {
    if {[info exists ::env($name)] && $::env($name) ne ""} { return $::env($name) }
    return $default
}

# ---------------------------------------------------------------------------
# 1. PROJECT / DESIGN
# ---------------------------------------------------------------------------
set ::DESIGN        picorv32                     ;# top module (picorv32 or picorv32_axi)
set ::PROJ_ROOT     [cfg_env PROJ_ROOT /proj/picorv32_45nm]   ;# DUMMY
set ::RTL_DIR       $::PROJ_ROOT/rtl
set ::RTL_FILES     [list $::RTL_DIR/picorv32.v]  ;# testbench.v is NOT synthesised
set ::RUN_TAG       [cfg_env RUN_TAG run1]        ;# change per experiment

# ---------------------------------------------------------------------------
# 2. OUTPUT DIRECTORIES (all created automatically by the scripts)
# ---------------------------------------------------------------------------
set ::RUN_DIR       $::PROJ_ROOT/runs/$::RUN_TAG
set ::LOG_DIR       $::RUN_DIR/logs
set ::SYN_OUT_DIR   $::RUN_DIR/synth/outputs
set ::SYN_RPT_DIR   $::RUN_DIR/synth/reports
set ::PNR_OUT_DIR   $::RUN_DIR/pnr/outputs
set ::PNR_RPT_DIR   $::RUN_DIR/pnr/reports
set ::PNR_DB_DIR    $::RUN_DIR/pnr/db          ;# one checkpoint per step
set ::SIGNOFF_DIR   $::RUN_DIR/signoff
set ::LEC_DIR       $::RUN_DIR/lec

# ---------------------------------------------------------------------------
# 3. TECHNOLOGY / PDK  (DUMMY LOCATIONS - replace with your foundry kit)
# ---------------------------------------------------------------------------
set ::PDK_ROOT      /pdk/foundry45nm                       ;# DUMMY
set ::STD_ROOT      $::PDK_ROOT/stdcell_hvt_rvt            ;# DUMMY

# --- Liberty (.lib) : one set per PVT corner ---
#   SS = slow (setup signoff)   FF = fast (hold signoff)   TT = typical (power)
set ::SS_LIBS [list $::STD_ROOT/lib/std45_ss_0p95v_125c.lib]   ;# DUMMY
set ::FF_LIBS [list $::STD_ROOT/lib/std45_ff_1p05v_m40c.lib]   ;# DUMMY
set ::TT_LIBS [list $::STD_ROOT/lib/std45_tt_1p00v_25c.lib]    ;# DUMMY

# --- LEF ---
set ::TECH_LEF      $::PDK_ROOT/lef/tech_45nm.lef          ;# DUMMY
set ::STD_LEF       $::STD_ROOT/lef/std45_cells.lef        ;# DUMMY
set ::LEF_FILES     [list $::TECH_LEF $::STD_LEF]

# --- QRC technology files (one per RC corner) ---
set ::QRC_RCWORST   $::PDK_ROOT/qrc/rcworst/qrcTechFile    ;# DUMMY
set ::QRC_RCBEST    $::PDK_ROOT/qrc/rcbest/qrcTechFile     ;# DUMMY
set ::QRC_RCTYP     $::PDK_ROOT/qrc/typical/qrcTechFile    ;# DUMMY

# --- GDS ---
set ::STD_GDS       $::STD_ROOT/gds/std45_cells.gds        ;# DUMMY
set ::GDS_MAP       $::PDK_ROOT/gds/innovus_stream_out.map ;# DUMMY (layer map)
set ::GDS_UNITS     1000
set ::GDS_LIBNAME   DesignLib

# --- Signoff decks (Pegasus / PVS / Calibre) ---
set ::DRC_DECK      $::PDK_ROOT/drc/drc_45nm.rul           ;# DUMMY
set ::LVS_DECK      $::PDK_ROOT/lvs/lvs_45nm.rul           ;# DUMMY

# ---------------------------------------------------------------------------
# 4. STANDARD-CELL NAMES  (DUMMY - replace with real names from your library)
# ---------------------------------------------------------------------------
set ::DONT_USE_CELLS    [list *_X0P5* *DLY* *SDFF*_X0*]    ;# patterns, tune!
set ::CTS_BUF_CELLS     [list CLKBUF_X2 CLKBUF_X3 CLKBUF_X4 CLKBUF_X8 CLKBUF_X12]
set ::CTS_INV_CELLS     [list CLKINV_X2 CLKINV_X4 CLKINV_X8 CLKINV_X12]
set ::CTS_ICG_CELLS     [list]                              ;# e.g. ICG_X2 (unused: no CG)
set ::FILLER_CELLS      [list FILL_X32 FILL_X16 FILL_X8 FILL_X4 FILL_X2 FILL_X1]
set ::DECAP_CELLS       [list]                              ;# optional decap fillers
set ::TAP_CELL          TAP_X1                              ;# "" if library has none
set ::ENDCAP_CELL       ""                                  ;# "" if library has none
set ::ANTENNA_CELL      ANTENNA_X1                          ;# "" to disable diode insertion
set ::CORE_SITE         CoreSite

# ---------------------------------------------------------------------------
# 5. POWER INTENT / PG
# ---------------------------------------------------------------------------
set ::PWR_NET           VDD
set ::GND_NET           VSS
set ::VDD_NOMINAL       1.00
set ::IR_DROP_LIMIT_PCT 5          ;# static IR budget in % of VDD

# metal stack (generic 10-metal 45nm: odd = horizontal, even = vertical)
set ::BOT_ROUTE_LAYER   metal2
set ::TOP_ROUTE_LAYER   metal8
set ::PG_RING_H         metal9
set ::PG_RING_V         metal10
set ::PG_STRIPE_V       metal10
set ::PG_STRIPE_H       metal9
set ::PG_BOT_LAYER      metal1
set ::PG_TOP_LAYER      metal10

# ---------------------------------------------------------------------------
# 6. FLOORPLAN
# ---------------------------------------------------------------------------
set ::FP_ASPECT         1.0
set ::FP_UTIL           0.65       ;# core utilisation (regfile is flop-based: be generous)
set ::FP_MARGIN         12.0       ;# um, core-to-die on all four sides (room for rings)

# ---------------------------------------------------------------------------
# 7. TIMING / MMMC
# ---------------------------------------------------------------------------
set ::MMMC_FILE         $::PROJ_ROOT/config/mmmc.tcl
set ::SDC_FUNC          $::PROJ_ROOT/constraints/picorv32_func.sdc
set ::SDC_SCAN          $::PROJ_ROOT/constraints/picorv32_scan.sdc
set ::CLK_PERIOD        3.0        ;# ns  (333 MHz functional) - tune after first run
set ::SCAN_PERIOD       20.0       ;# ns  (50 MHz shift)
set ::SETUP_VIEW        func_ss    ;# main setup view
set ::HOLD_VIEW         func_ff    ;# main hold view
set ::POWER_VIEW        func_tt    ;# leakage / dynamic power view
set ::SETUP_TARGET_SLACK 0.0
set ::HOLD_TARGET_SLACK  0.03      ;# ns hold margin for OCV

# ---------------------------------------------------------------------------
# 8. DFT
# ---------------------------------------------------------------------------
set ::DFT_ENABLE        1
set ::DFT_N_CHAINS      4          ;# number of scan chains (balanced automatically)
set ::DFT_SE_PORT       SE         ;# scan-enable port created by Genus
set ::DFT_PREFIX        DFT_       ;# Genus names ports DFT_sdi_<n>/DFT_sdo_<n>

# ---------------------------------------------------------------------------
# 9. FLOW CONTROL
# ---------------------------------------------------------------------------
set ::NUM_CPUS          [cfg_env NUM_CPUS 8]
set ::DO_METAL_FILL     0          ;# 1 = run Innovus add_metal_fill (usually done in signoff tool)
set ::START_STEP        [cfg_env START_STEP 1]   ;# Innovus restart control
set ::STOP_STEP         [cfg_env STOP_STEP 11]
