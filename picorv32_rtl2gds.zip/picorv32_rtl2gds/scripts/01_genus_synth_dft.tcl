###############################################################################
# 01_genus_synth_dft.tcl  -  Genus: RTL -> gate netlist + scan insertion (DFT)
# -----------------------------------------------------------------------------
# Run   : genus -no_gui -f scripts/01_genus_synth_dft.tcl -log logs/genus.log
# Steps : S1 setup  S2 read MMMC/LEF/RTL  S3 elaborate + checks
#         S4 synthesis settings  S5 DFT settings  S6 generic synthesis
#         S7 mapping (scan-flop mapping)  S8 DFT rule check + scan connect
#         S9 optimisation  S10 reports  S11 write outputs
# Output: netlist, post-synth SDC, SCANDEF, ATPG hand-off, reports, LEC do-file
###############################################################################

set ::TOOL  genus
set ::STAGE synth

# ---- load configuration ----------------------------------------------------
if {[info exists ::env(PROJ_ROOT)]} {
    source $::env(PROJ_ROOT)/config/design_config.tcl
} else {
    source [file join [file dirname [info script]] .. config design_config.tcl]
}

# safe wrapper for NON-critical commands: a failure is logged, flow continues
proc safe {args} {
    if {[catch {uplevel 1 [join $args " "]} err]} {
        puts "WARNING (non-fatal): [lindex $args 0] failed -> $err"
    }
}
proc banner {txt} {
    puts "\n#############################################################"
    puts "# $txt"
    puts "#############################################################"
}

# ============================================================================
# S1. SETUP
# ============================================================================
banner "S1: setup"
file mkdir $::SYN_OUT_DIR $::SYN_RPT_DIR $::LOG_DIR $::LEC_DIR

set_db init_hdl_search_path   $::RTL_DIR
set_db max_cpus_per_server    $::NUM_CPUS
set_db hdl_error_on_blackbox  true          ;# missing module = hard error
set_db information_level      6

# ============================================================================
# S2. READ MMMC, PHYSICAL (LEF) AND RTL
#     LEF is read at synthesis so Genus uses physical-aware wire-load (PLE)
# ============================================================================
banner "S2: read MMMC / LEF / RTL"
read_mmmc     $::MMMC_FILE
read_physical -lef $::LEF_FILES
read_hdl      $::RTL_FILES                  ;# picorv32.v is Verilog-2001

# ============================================================================
# S3. ELABORATE + CHECKS
#     (To change PicoRV32 parameters such as ENABLE_MUL/ENABLE_IRQ, edit the
#      parameter defaults in a COPY of picorv32.v - see PDF chapter 3)
# ============================================================================
banner "S3: elaborate"
elaborate $::DESIGN
current_design $::DESIGN
init_design                                ;# applies MMMC constraints to the design

check_design -unresolved                   ;# must be 0 unresolved references
check_timing_intent                        ;# unconstrained / missing constraints
report_clocks > $::SYN_RPT_DIR/clocks_pre_synth.rpt

# ============================================================================
# S4. SYNTHESIS SETTINGS
# ============================================================================
banner "S4: synthesis settings"
set_db syn_generic_effort high
set_db syn_map_effort     high
set_db syn_opt_effort     high
set_db interconnect_mode  ple               ;# physical layout estimation from LEF/QRC

# dont_use cells (delay cells, tiny X0P5 cells, etc.)
foreach pat $::DONT_USE_CELLS {
    safe set_db \[get_db base_cells $pat\] .dont_use true
}

# ============================================================================
# S5. DFT SETTINGS (muxed-scan, single clock, rising edge)
# ============================================================================
if {$::DFT_ENABLE} {
    banner "S5: DFT settings"
    set_db dft_scan_style                              muxed_scan
    set_db dft_prefix                                  $::DFT_PREFIX
    # map flops directly to scan flops, but only if they pass the DFT rules
    set_db dft_scan_map_mode                           tdrc_pass
    # during mapping tie SE low and loop SI to Q; real hookup is done later
    set_db dft_connect_shift_enable_during_mapping     tie_off
    set_db dft_connect_scan_data_pins_during_mapping   loopback

    # scan-enable port (active high) created at top level
    define_shift_enable -name $::DFT_SE_PORT -active high -create_port $::DFT_SE_PORT
}

# ============================================================================
# S6. GENERIC SYNTHESIS
# ============================================================================
banner "S6: syn_generic"
syn_generic
report_area > $::SYN_RPT_DIR/area_generic.rpt

# ============================================================================
# S7. MAPPING TO TECHNOLOGY CELLS
# ============================================================================
banner "S7: syn_map"
syn_map
report_qor  > $::SYN_RPT_DIR/qor_mapped.rpt

# ============================================================================
# S8. DFT : RULE CHECK  ->  SCAN CHAIN CONNECTION
# ============================================================================
if {$::DFT_ENABLE} {
    banner "S8: DFT rule check + scan chain connection"
    check_dft_rules > $::SYN_RPT_DIR/dft_rules_pre_connect.rpt
    report_scan_registers > $::SYN_RPT_DIR/scan_registers_pre.rpt

    # number of chains (balanced automatically by Genus)
    set_db [current_design] .dft_min_number_of_scan_chains $::DFT_N_CHAINS

    connect_scan_chains -auto_create_chains -preview > $::SYN_RPT_DIR/scan_chains_preview.rpt
    connect_scan_chains -auto_create_chains
}

# ============================================================================
# S9. LOGIC / DFT-AWARE OPTIMISATION
# ============================================================================
banner "S9: syn_opt"
syn_opt

# ============================================================================
# S10. REPORTS
# ============================================================================
banner "S10: reports"
report_timing -max_paths 20 > $::SYN_RPT_DIR/timing_setup.rpt
report_qor                  > $::SYN_RPT_DIR/qor_final.rpt
report_area                 > $::SYN_RPT_DIR/area_final.rpt
report_gates                > $::SYN_RPT_DIR/gates.rpt
report_power                > $::SYN_RPT_DIR/power.rpt
check_design                > $::SYN_RPT_DIR/check_design.rpt
check_timing_intent         > $::SYN_RPT_DIR/check_timing_intent.rpt
if {$::DFT_ENABLE} {
    check_dft_rules         > $::SYN_RPT_DIR/dft_rules_final.rpt
    report_scan_chains      > $::SYN_RPT_DIR/scan_chains.rpt
    report_scan_registers   > $::SYN_RPT_DIR/scan_registers_final.rpt
    safe report_scan_setup  > $::SYN_RPT_DIR/scan_setup.rpt
}

# ============================================================================
# S11. WRITE OUTPUTS
# ============================================================================
banner "S11: write outputs"
set netlist $::SYN_OUT_DIR/${::DESIGN}_synth.v
write_hdl > $netlist
write_sdc > $::SYN_OUT_DIR/${::DESIGN}_synth.sdc
safe write_sdf > $::SYN_OUT_DIR/${::DESIGN}_synth.sdf

if {$::DFT_ENABLE} {
    # SCANDEF : read by Innovus so placement keeps scan chains short
    write_scandef > $::SYN_OUT_DIR/${::DESIGN}.scandef
    # ATPG hand-off for Modus (check your Genus release for exact options)
    safe write_dft_atpg -library $::SS_LIBS -directory $::SYN_OUT_DIR/atpg
}

# LEC do-file generated by Genus (RTL vs mapped netlist). Our own tuned
# do-file is scripts/02_conformal_lec.do
safe write_do_lec -no_exit -golden_design rtl -revised_design $netlist \
    > $::LEC_DIR/lec_genus_generated.do

puts "\nGenus finished OK. Netlist: $netlist"
exit
